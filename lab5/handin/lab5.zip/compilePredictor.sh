# Holly Haraguchi and Kevin Costello
# Lab 5
# CPE 369, Winter 2017
# Compiles ratingsPredictor.java with the necessary .jar files

javac -cp json-simple-1.1.1.jar:mongo-java-driver-3.4.2.jar ratingsPredictor.java
